<?php
require 'config.php';
session_start();
    if(isset($_POST['submit']))
    {
        if(!empty($_POST['Username']) && !empty($_POST['password']))
        {
    $Username=$_POST['Username'];
    $password=$_POST['password'];
    $sql="SELECT * FROM Register WHERE Username='$Username' AND password='$password'";
    $result=mysqli_query($con,$sql);
    if(mysqli_num_rows($result)==1)
    {
      $row=mysqli_fetch_assoc($result);
      if($row['Username']==$Username && $row['password']==$password)
      {
        $_SESSION['Username']=$row['Username'];
        $_SESSION['password']=$row['password'];
        header("Location: Student_dashboard.php");
      }
      
    }else
    {
      echo "<script>alert('INCORRECT USERNAME AND PASSWORD');</script>";
    }
            }
        }
    ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Login Page</title>
    </head>
    <body>
        <script>
            function create()
            {
                var c,d;
                c=document.getElementById("us").value;
                d=document.getElementById("pa").value;
 
                var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&amp;*-])/;
                var letters = /^[A-Za-z]+$/;
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
               
            else if(c=='')
            {
                window.alert("Enter the username");
            }
            else if(!letters.test(c))
            {
            window.alert("User name field required only alphabet characters");
            }
            else if(d=='')
            {
                window.alert("Enter the password");
            }
            else if(!pwd_expression.test(d))
            {
 
     window.alert ("Upper case, Lower case, Special character and Numeric letter are required in Password filed");
            }
        }
        function myFunction() {
  var x = document.getElementById("pa");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}            </script>
             <div id="logo">&emsp;WHITEHOUSE&ensp;<b style="color:#2c7ad6;">HOSTEL...</b>
             </div>
            <div class="one">
                <h3>Student Login</h3>
                <div class="two">
                    <form action="" method="POST">
                    <hr>
                    <br><label>Username:</label><br><br>
                    <input type="text" id="us" name="Username" ><br><br>
                    <label>Password:</label> <br><br>
                    <input type="text" style="-webkit-text-security: circle" onfocus="myFunction()" id="pa" name="password" required><br><br>
                    <button type="submit" onclick="create()" id="button" name="submit">Login</button><br><br>
                    <span class="psw"><a href="forget_password.php" style="font-size: 12px;"> Forgot password?</a></span>
                </form>
                </div>
            </div>
            <style>
                BODY{
            margin: 0;
            padding: 0;
            text-align: center;
            font-family: sans-serif;
            background-image:url("home.jpg");
            background-size: cover;
            min-height: 100vh;
                }
                #logo{
    height: 65px;
    width: 100%;
    background:rgb(10, 10, 10);
    text-align:left;
    line-height: 65px;
    font-size: 30px;
    float: left;
    color: white;
}
                .one{
        
            width: 500px;
            height: 370px;
            position: absolute;
            top: 60%;
            left: 50%;
            background-color: #fff;
            transform: translate(-50%,-50%);
            padding: 20pxx;
            border-radius: 10px;
            box-shadow: 1p 1px 20px #ee5253;
             }
             #us,#pa{
            color: #222f3e;
            text-align: left;
            font-size: 20px;
            font-weight: 200;
            outline: none;
            border :none;
            background: none;
            border-bottom: 1px solid #341f97;
            width: 200px;
        }
        #us:focus,#pa:focus{
            border-bottom: 2px solid #341f97;
            width: 300px;
            transition: 0.5s;}
        
                #button{
            font-family: inherit;
            margin-top: 10px;
            border: none;
            color:whitesmoke;
            background-image: linear-gradient(180deg, rgb(10, 58, 85), rgb(69, 154, 173));
            width: 150px;
            padding: 10px;
            border-radius: 30px;
            outline: none;
            cursor: pointer;
        }
        #button:hover{
            box-shadow: 1px 1px 10px #341f97;
        }
            
    
                hr{
                    margin-left:0px;
                    margin-right: 0px;
                    
                }
            </style>
    </body>
    
</html>