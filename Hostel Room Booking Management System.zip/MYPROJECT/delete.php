<?php
require "config.php";
if (isset($_GET['id'])) {
	$id = $_GET['id'];
    $sql= "DELETE FROM registration,register WHERE id=$id";
    $result=mysqli_query($con,$sql);
	 
	header('location: admin_studentreg.php');
}
?>