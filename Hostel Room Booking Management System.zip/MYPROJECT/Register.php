<?php
require 'config.php';
        if(isset($_POST["submit"]))
        {
            if(!empty($_POST['first_name']) && !empty($_POST['mail_id']) && !empty($_POST['gender']) && !empty($_POST['Username']) && !empty($_POST['password']))
            {
            $first_name=$_POST['first_name'];
            $mail_id=$_POST['mail_id'];
            $gender=$_POST['gender'];
            $Username=$_POST['Username'];
            $password=$_POST['password'];
        $sql="INSERT INTO Register(first_name,mail_id,gender,Username,password) VALUES('$first_name','$mail_id','$gender','$Username','$password')";
        $result=mysqli_query($con,$sql);
        }
        }
        ?>
        
        <!DOCTYPE html>
<html>
    <head>
        <title>Registration Page</title>
    </head>
    <body>
        <script>
            function create()
            {
                var a,b,c,d,e,f;
                a=document.getElementById("name").value;
                b=document.getElementById("em").value;
                f=document.getElementById("Gen").value;
                c=document.getElementById("us").value;
                d=document.getElementById("pa").value;
                e=document.getElementById("cp").value;
 
                var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&amp;*-])/;
                var letters = /^[A-Za-z]+$/;
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
               
            if((a=='') && (b=='') && (c=='') && (d=='') && (e==''))
            {
                window.alert("Enter the Details");
            }
            else if(a=='')
            {
                window.alert("Enter the name");
            }
                else if(!letters.test(a))
                {
                window.alert('Name field required only alphabet characters');
                }
                
            else if(b=='')
            {
                window.alert("Enter the mailid");
            }
            else if (!filter.test(b))
            {
          window.alert("Invalid email");
            }
            else if(c=='')
            {
                window.alert("Enter the username");
            }
            else if(!letters.test(c))
            {
            window.alert("User name field required only alphabet characters");
            }
            else if(d=='')
            {
                window.alert("Enter the password");
            }
            else if(!pwd_expression.test(d))
            {
 
     window.alert ("Upper case, Lower case, Special character and Numeric letter are required in Password filed");
            }
            else if(d!= e)
            {
            window.alert ("Password not Matched");
            }
            else if(e=='')
            {
                window.alert("Enter the confirm password");
            }
            else
            {
                window.alert("!Successfully Registered");
            }
            }
            function myFunction() {
  var x = document.getElementById("pa");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
function myFunction2() {
  var y = document.getElementById("cp");
  if (y.type === "password") {
    y.type = "text";
  } else {
    y.type = "password";
  }
}
            function reset()
            {
                document.getElementById("name").value="";
                document.getElementById("em").value="";
                document.getElementById("Gen").value="";
                document.getElementById("us").value="";
                document.getElementById("pa").value="";
                document.getElementById("cp").value="";
            }
 
            </script>
            <div id="logo">&emsp;WHITEHOUSE&ensp;<b style="color:#2c7ad6;">HOSTEL...</b>
            </div>
            <div class="one">
                <br><h3>Student Registration</h3>
                <div class="two">
                    <form action="" method="POST">
                    <hr>
                    <label>Enter Name:</label>&emsp;&emsp;&emsp;
                    <input type="text" id="name" name="first_name" title="Name field required only alphabet characters"required><br><br>
                    <label>Enter Mail-id:</label>&emsp;&emsp;
                    <input type="email" id="em" name="mail_id" title="Enter the mail_id in correct format"><br><br>
                    <label> Gender</label>&emsp;
                    <input type="radio" id="Gen" name="gender" value="male"> Male
                    <input type="radio" id="Gen" name="gender" value="female"> Female
                    <input type="radio" id="Gen"name="gender" value="female"> Others<br><br>
                    <label>Enter Username:</label>&emsp;
                    <input type="text" id="us" name="Username" title="User name field required only alphabet characters" required><br><br>
                    <label>Enter Password:</label>&emsp;
                    <input type="text" onfocus="myFunction()" id="pa" name="password"title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required ><br><br>
                    <label>Confirm Password:</label>
                    <input type="text" onfocus="myFunction2()" id="cp" name="confirm"><br><br>
                   <button onclick="reset()">Clear form</button>
                    <button onclick="create()" name="submit">Create account</button><br><br>
                </form>
                    <a href ="Home.html">
                    <button onclick="reset()">Back</button>
                    </a><br>
                </div>
            </div>

        
            <style>
                BODY{
            margin: 0;
            padding: 0;
            text-align: center;
            font-family: sans-serif;
            background-image:url("home.jpg");
            min-height: 100vh;
            background-size: cover;
                }
             #logo{
            height: 65px;
            width: 100%;
            background:rgb(10, 10, 10);
            text-align:left;
            line-height: 65px;
            font-size: 30px;
            float: left;
            color: white;
        }
                .one{
        
            width: 510px;
            height: 500px;
            position: absolute;
            top: 55%;
            left: 50%;
            background-color: #fff;
            transform: translate(-50%,-50%);
            padding: 20pxx;
            border-radius: 10px;
            box-shadow: 1p 1px 20px #ee5253;
             }
             #name,#em,#us,#pa,#cp{
            color: #222f3e;
            text-align: left;
            font-size: 20px;
            font-weight: 200;
            outline: none;
            border :none;
            background: none;
            border-bottom: 1px solid #341f97;
            width: 200px;
        }
        #name:focus,#em:focus,#us:focus,#pa:focus,#cp:focus{
            border-bottom: 2px solid #341f97;
            width: 300px;
            transition: 0.5s;}
        
                button{
            font-family: inherit;
            margin-top: 10px;
            border: none;
            color:whitesmoke;
            background-image: linear-gradient(180deg, rgb(10, 58, 85), rgb(69, 154, 173));
            width: 150px;
            padding: 10px;
            border-radius: 30px;
            outline: none;
            cursor: pointer;
        }
        #button:hover{
            box-shadow: 1px 1px 10px #341f97;
        }
            
    
                hr{
                    margin-left:0px;
                    margin-right: 0px;
                    
                }
            </style>
    </body>
    
</html>