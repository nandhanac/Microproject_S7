<?php
 $con=mysqli_connect("localhost","root","","Project");
 if($con==FALSE)
 {
    die("ERROR: Cannot connect ".mysqli_connect_error());
 }
 ?>