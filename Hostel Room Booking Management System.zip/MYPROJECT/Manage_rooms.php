<?php
require 'config.php';
        if(isset($_POST["submit"]))
        {
            if(!empty($_POST['seater']) && !empty($_POST['room_no']) && !empty($_POST['fees']))
            {
            $seater=$_POST['seater'];
            $room_no=$_POST['room_no'];
            $fees=$_POST['fees'];
        $sql="INSERT INTO rooms(seater,room_no,fees) VALUES('$seater','$room_no','$fees')";
        $result=mysqli_query($con,$sql);
        if($result)
    {
        echo "<script>alert('SUCCESSFULLY ADDED');</script>";
        
    }
}
        }
        ?>
        
        <!DOCTYPE html>
<html>
    <head>
        <title>Registration Page</title>
    </head>
    <body>
            <div class="one">
                <br><h3>ADD ROOM</h3>
                <div class="two">
                    <form action="" method="POST">
                    <hr>
                    <label>Enter Seater:</label>&emsp;&emsp;
                    <input type="seater" id="em" name="seater"><br><br>
                    <label>Enter Room_NO:</label>&emsp;
                    <input type="text" id="us" name="room_no"><br><br>
                    <label>Enter Fee structure:</label>&emsp;
                    <input type="text" id="pa" name="fees"><br><br>
                    <button onclick="create()" name="submit">ADD</button><br><br>
                </form>
                    <a href ="Admin_profile.php">
                    <button onclick="reset()">Back</button>
                    </a><br>
                </div>
            </div>

        
            <style>
                BODY{
            margin: 0;
            padding: 0;
            text-align: center;
            font-family: sans-serif;
            background-image:url("home.jpg");
            min-height: 100vh;
            background-size: cover;
                }
                .one{
        
            width: 510px;
            height: 400px;
            position: absolute;
            top: 55%;
            left: 50%;
            background-color: #fff;
            transform: translate(-50%,-50%);
            padding: 20pxx;
            border-radius: 10px;
            box-shadow: 1p 1px 20px #ee5253;
             }
             #name,#em,#us,#pa,#cp{
            color: #222f3e;
            text-align: left;
            font-size: 20px;
            font-weight: 200;
            outline: none;
            border :none;
            background: none;
            border-bottom: 1px solid #341f97;
            width: 200px;
        }
        
                button{
            font-family: inherit;
            margin-top: 10px;
            border: none;
            color:whitesmoke;
            background-image: linear-gradient(180deg, rgb(10, 58, 85), rgb(69, 154, 173));
            width: 150px;
            padding: 10px;
            border-radius: 30px;
            outline: none;
            cursor: pointer;
        }
        #button:hover{
            box-shadow: 1px 1px 10px #341f97;
        }
            
    
                hr{
                    margin-left:0px;
                    margin-right: 0px;
                    
                }
            </style>
    </body>
    
</html>